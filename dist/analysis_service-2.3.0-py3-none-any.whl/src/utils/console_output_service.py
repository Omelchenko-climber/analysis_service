class ConsoleOutput:

    def console_output(info: str) -> None:
        print(info)